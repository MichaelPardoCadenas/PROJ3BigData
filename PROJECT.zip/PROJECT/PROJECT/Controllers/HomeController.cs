using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using Microsoft.Extensions.Logging; // Ensure this is included for ILogger
using CountriesApp.Models; // Ensure 'Country' model is correctly defined here
using PROJECT.Models; // Ensure 'ErrorViewModel' is correctly defined here

namespace PROJECT.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    // Method to display all countries (optional for the randomizer feature)
    public async Task<IActionResult> Index()
    {
        string baseUrl = "https://restcountries.com/v3.1/all";

        try
        {
            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(baseUrl);
                var stringContent = await response.Content.ReadAsStringAsync();
                var countries = JsonConvert.DeserializeObject<List<Country>>(stringContent);

                return View(countries);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error fetching countries: {ex.Message}");
            return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }

    // Method to display a random flag
    public async Task<IActionResult> Randomizer()
    {
        string baseUrl = "https://restcountries.com/v3.1/all";

        try
        {
            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(baseUrl);
                var stringContent = await response.Content.ReadAsStringAsync();
                var countries = JsonConvert.DeserializeObject<List<Country>>(stringContent);

                // Select a random country
                var random = new System.Random();
                var randomCountry = countries[random.Next(countries.Count)];

                // Prepare the data for the view using ViewBag
                ViewBag.RandomFlag = randomCountry.Flags.Png;
                ViewBag.RandomCountry = randomCountry.Name.Common;

                return View();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error in Randomizer: {ex.Message}");
            return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
        public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
